import java.applet.*;
import java.awt.*;

public class MyApplet extends Applet{
   public void paint(Graphics g){
      g.drawString("KAKOGO HRENA YEMU NE REBOTAT'",40,20);
   }
}